import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, accuracy_score

# Import CSV file
df = pd.read_csv("feature list.csv", sep=";")

# Select only relevant columns
df = df[['Feature', 'content-related focus', 'content-related update cycle', 'Taxonomy']] # , 'modelling method', 'data sources', 'data collection'

# Remove rows with missing values
df = df.dropna()

# Convert categorical data with label encoding
label_encoders = {}
for col in df.columns:
  le = LabelEncoder()
  df[col] = le.fit_transform(df[col])
  label_encoders[col] = le

# Separate features and target column
X = df.drop('Taxonomy', axis=1)
y = df['Taxonomy']

# Split training and test data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Entscheidungsbaum
clf = DecisionTreeClassifier(random_state=42)
clf.fit(X_train, y_train)

# Predictions and evaluation
y_pred = clf.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))

###################################################################################################

# Example: Decoding the predictions
decoded_preds = label_encoders['Taxonomy'].inverse_transform(y_pred)
print("Decoded predictions:", decoded_preds)

###################################################################################################

import matplotlib.pyplot as plt
from sklearn.tree import plot_tree

for col in df.columns:
  df[col] = df[col].astype(str)
  le = LabelEncoder()
  df[col] = le.fit_transform(df[col])
  label_encoders[col] = le

class_names = [str(cls) for cls in label_encoders['Taxonomy'].classes_]

plt.figure(figsize=(18, 10))
plot_tree(clf,
          feature_names=X.columns,
          class_names=class_names,
          filled=True,
          rounded=True,
          fontsize=10)
plt.title("Decision Tree")
plt.show()