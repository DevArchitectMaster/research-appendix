import matplotlib.pyplot as plt
from upsetplot import from_memberships, plot

example = from_memberships(
    [
        ['birthdate'],
        ['degree'],
        ['gender'],
        ['degree', 'birthdate'],
        ['degree', 'gender'],
        ['birthdate', 'gender'],
        ['degree', 'birthdate', 'gender'],
    ],
    data=[3, 5, 1, 4, 1, 0, 1]
)

result_plot = plot(example)
result_plot["intersections"].set_ylabel("subset size")
result_plot["totals"].set_xlabel("total size")

plt.savefig(f"plot/upset_sample.png")

