# README

## Content
_This Python project is used to reproduce the charts from the publication together with the required data._

## Manual

### Installation
1. Creating a virtual Python environment  
`python -m venv <name_of_the_environment>`
2. Activate virtual Python environment  
`source <name_of_the_environment>/Scripts/activate`
3. Install all required dependencies (pip packages) in the new virtual Python environment  
`pip install -r requirements.txt`

### Execution
_All generated charts are stored in the `./plot` subfolder._   
_The database required to generate the charts is contained in the file `data.csv`._
 - The file `sample_plot.py` creates an example UpSetPlot.
 - The file `main.py` creates all included UpSetPlots and stacked bar charts from the publication.
 - The file `counting.py` is used to pre-process the data (normalise, count, ...).