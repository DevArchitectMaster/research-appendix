import os
from upsetplot import from_memberships, plot
from matplotlib import pyplot
from counting import *
from collections import Counter
import matplotlib.ticker as ticker

def clean_filename(column_name):
    return column_name.replace(" ", "_").replace("(", "").replace(")", "").replace("[", "").replace("]", "").replace(
        "{", "").replace("}", "").lower()


def plot_stacked_bar_chart(category_counts_by_year, column_name):
    """
    Plot stacked bar chart for category counts over time.
    """

    # Custom color palette
    colors = ["#009392", "#39B185", "#9CCB86", "#E9E29C", "#EEB479", "#E88471", "#CF597E", "#4682B4", "#1C658C"]

    all_categories = set()
    for year, category_counts in category_counts_by_year.items():
        all_categories.update(category_counts.keys())

    data = []
    for year in sorted(category_counts_by_year.keys()):
        counts = category_counts_by_year[year]
        for category in all_categories:
            data.append({
                'Year': year,
                'Category': category,
                'Count': counts.get(category, 0)
            })

    df_plot = pd.DataFrame(data)

    df_pivot = df_plot.pivot(index='Year', columns='Category', values='Count').fillna(0)

    ax = df_pivot.plot(
        kind='bar',
        stacked=True,
        figsize=(12, 6),
        color=colors
    )

    ax.set_xticks(range(len(df_pivot.index)))
    ax.set_xticklabels(df_pivot.index, rotation=45)

    pyplot.title(f'Parent Data Category of Taxonomy Over Time')
    pyplot.xlabel('Date')
    pyplot.ylabel('Normalized Occurrences (Usage / Total Count)')
    pyplot.legend(title='Category', bbox_to_anchor=(1.05, 1), loc='upper left')
    pyplot.tight_layout()

    pyplot.savefig(f'plot/{clean_filename(column_name)}_stacked_bar_chart.png', dpi=300, bbox_inches='tight')
    pyplot.close()

def create_upset_plot(df, column_name, threshold=0):
    """
    Generates an upset plot for a specified column in the DataFrame, based on
    semicolon-separated categories.

    Args:
    df (pandas.DataFrame): The input DataFrame containing the data.
    column_name (str): The column for which the upset plot should be generated.
    threshold (int): Minimum count for categories to appear in the plot.

    Returns:
    None
    """

    df[column_name] = df[column_name].apply(
        lambda x: process_category(x, return_frozenset=True) if pd.notna(x) and x != '---' else None)

    category_counts = Counter(df[column_name].dropna())
    filtered_counts = {key: value for key, value in category_counts.items() if value > threshold}

    # Extract data for upset plot
    memberships = list(filtered_counts.keys())
    data = list(filtered_counts.values())

    upset_data = from_memberships(memberships, data=data)
    os.makedirs('plot', exist_ok=True)
    result_plot = plot(upset_data)

    # Set labels and tick formatting
    result_plot["intersections"].set_ylabel("subset size")
    result_plot["totals"].set_xlabel("total size")
    result_plot["intersections"].yaxis.set_major_locator(ticker.MultipleLocator(5))
    result_plot["intersections"].yaxis.set_major_formatter(ticker.FormatStrFormatter('%d'))

    clean_name = clean_filename(column_name)
    print('Saving upset plot', clean_name)
    pyplot.savefig(f"plot/{clean_name}_upset_plot.png", dpi=300, bbox_inches='tight')
    pyplot.close()

def main(df, columns, threshold=0):
    """
    Main function to generate plots for specified columns in the DataFrame.

    Args:
    df (pandas.DataFrame): The input DataFrame containing the data.
    columns (list of str): List of column names for which to generate plots.
    threshold (int): Minimum count for categories to appear in the plot.

    Returns:
    None
    """

    # Generate plot for each given column
    for column in columns:
        print(f"Creating upset plot for column: {column}")
        create_upset_plot(df, column, threshold=threshold)

        category_counts_by_year = count_categories_per_year(df, column)
        print(f"Creating bar chart for column: {column}")
        plot_stacked_bar_chart(category_counts_by_year, column)

# USAGE
if __name__ == "__main__":

    # Provide data path
    csv_path = 'data.csv'

    df, unique_value_counts = normalize_and_count('data.csv')

    # Select the columns for plotting
    selected_columns_0 = ['Init Data Source', 'Data Source']
    selected_columns_1 = ['Data Category','Data Parent', 'Modelling Technique']

    # Generate plots with different thresholds
    main(df, selected_columns_0, threshold=0)
    main(df, selected_columns_1, threshold=1)