import pandas as pd
from collections import Counter

def process_category(category, return_frozenset=True):
    """
    Converts a semicolon-separated string of categories into a frozenset or list.

    Args:
    category (str or frozenset): A semicolon-separated string of categories.
    return_frozenset (bool): Whether to return a frozenset (for upset plot) or a list (for counting categories).

    Returns:
    frozenset or list: A frozenset of categories if return_frozenset is True, otherwise a list of categories.
    """
    if isinstance(category, frozenset):
        return category if return_frozenset else list(category)

    # Process string values
    if isinstance(category, str):
        parts = [x.strip() for x in category.split(";") if x.strip()]
        return frozenset(parts) if return_frozenset else parts

    return frozenset() if return_frozenset else []

def count_categories_per_year(df, column_name):
    """
    Count the occurrences of individual categories per year from a semicolon-separated column,
    and normalize them based on the total number of papers for each year.
    """
    category_counts_by_year = {}
    total_papers_per_year = df['Year'].value_counts().to_dict()

    for year, group in df.groupby('Year'):
        category_counter = Counter()

        for categories in group[column_name].dropna():
            category_list = process_category(categories, return_frozenset=False)
            category_counter.update(category_list)

        normalized_category_counts = {category: count / total_papers_per_year[year]
                                      for category, count in category_counter.items()}

        category_counts_by_year[year] = normalized_category_counts

    return category_counts_by_year

def normalize_semicolon_separated(val):
    """
    Normalize semicolon-separated values, sort them, and join them back.
    """
    if pd.isna(val) or val == '---':
        return None
    if isinstance(val, str):
        items = [item.strip() for item in val.split(';')]
        return '; '.join(sorted(items))
    return val

def normalize_and_count(csv_path):
    """
    Reads the CSV data, normalizes relevant columns, and counts unique values.

    Args:
    csv_path (str): Path to the input CSV file.

    Returns:
    df (pandas.DataFrame): The processed DataFrame.
    unique_value_counts (dict): A dictionary of unique value counts for each column.
    """

    df = pd.read_csv(csv_path, encoding='utf-8-sig', sep=';')

    # Remove surveys from counts
    df = df[df['Survey'] != 'Yes']

    def normalize_semicolon_separated(val):
        if pd.isna(val) or val == '---':
            return None
        if isinstance(val, str):
            items = [item.strip() for item in val.split(';')]
            return '; '.join(sorted(items))
        return val

    print(f"Total papers: {len(df)}")

    # Print unique values and their frequencies, ignoring '---' and applying order-independence for semicolon-separated values
    def print_unique_values(df):
        unique_value_counts = {}
        for column in df.columns:

            # Ignore rows where the relevant column has '---' or is NaN
            filtered_column = df[column].dropna().apply(normalize_semicolon_separated)
            filtered_column = filtered_column[filtered_column.notna()]

            # Get unique values and their frequencies
            value_counts = filtered_column.value_counts()
            unique_value_counts[column] = value_counts  # Save the counts for later use

            print(f"\nColumn: {column}")
            print(value_counts)

        return unique_value_counts

    return df, print_unique_values(df)
