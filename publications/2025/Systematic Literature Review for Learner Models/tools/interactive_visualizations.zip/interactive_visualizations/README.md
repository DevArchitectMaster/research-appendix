# Interactive Visualization Tool

This tool can be used to explore the learner model data with interactive visualizations. The tool was developed in the context of the systematic literature review **"Learner Models: Design, Components, Structure, and Modelling: A Systematic Literature Review"** by F. Böck et al. It allows for easy, interactive exploration of the data complementing the results presented in the article.

![alt text](image.png)

## Setup

In order to use this interactive visualizer, you need to set up a HTTP-Server or use a live server extension such as VS Code Live Server.

**Node.js**
`
npx http-server
`

**Python3**
`
python -m http.server 8000
`

## Charts
This project contains several types of interactive visualizations:
- **BarChart** showing the number of publications per year
- **TreeChart** for a quick overview of the publications, their type and venue
- **NetworkChart** for exploring venue and author networks
- **TimelineChart** for exploring the evolution of various learner modeling aspects over time
- **ChordChart** for examining the relationships and co-occurrences of various learner modeling aspects
- **SankeyChart** for visualizing the learner modeling flow from data source to modeling approach

### Additional Charts
Further charts can be added under `/charts`. Note that this may require additional updates to the following files:
- d3 imports (`utils/d3-modules.js`)
- config (`config.js`)
- html elements (`index.html`)
- main (`main.js`)

## Data
The dataset that was used can be found in `data/data.json`. It synthesizes all relevant data that was elicited in the context of the literature review in this repo's main `/data` directory. The data combines the publications' quantitative meta information (`1st_iteration.bib`) with the elicited qualitative data (`research_data.csv`) in JSON format.

## License
d3.js -> [ISC](https://github.com/d3/d3?tab=ISC-1-ov-file)

## Paper Reference
F. Böck et al. Learner Models: Design, Components, Structure, and Modelling: A Systematic Literature Review.
