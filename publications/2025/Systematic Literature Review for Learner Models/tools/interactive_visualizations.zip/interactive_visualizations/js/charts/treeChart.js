import { CONFIG } from '../config.js';
import { DataLoader } from '../utils/dataLoader.js';
import { Tooltip, clearContainer, createSVG, buildHierarchy } from '../utils/helpers.js';

import {
    select,
    cluster,
} from '../utils/d3-modules.js';
import { getDimensions } from '../utils/helpers.js';

export class TreeChart {
    constructor(container, data) {
        this.container = container;
        this.data = data;
        this.config = getDimensions('tree');
        this.colors = CONFIG.colors;
        this.tooltip = new Tooltip();

        this.svg = null;
        this.tree = null;

        this.init();
    }

    init() {
        clearContainer(this.container);
        this.createSVG();
        this.setupTree();
    }

    createSVG() {
        this.svg = createSVG(this.container, this.config.width, this.config.height);
    }

    setupTree() {
        this.tree = cluster()
            .size([
                this.config.height - this.config.margin.top - this.config.margin.bottom,
                this.config.width - this.config.margin.left - this.config.margin.right
            ]);
    }

    render(yearRange) {
        const [startYear, endYear] = yearRange;
        const filteredData = DataLoader.filterByYearRange(this.data, startYear, endYear);

        this.svg.selectAll('.chart-content').remove();

        const chartGroup = this.svg.append('g')
            .attr('class', 'chart-content')
            .attr('transform', `translate(${this.config.margin.left},${this.config.margin.top})`);

        this.addTitle(chartGroup);

        const root = buildHierarchy(filteredData);
        this.tree(root);

        this.createLinks(chartGroup, root);
        this.createNodes(chartGroup, root);
    }

    addTitle(container) {
        container.append('text')
            .attr('class', 'chart-title')
            .attr('x', 0)
            .attr('y', -30)
            .style('font-size', '18px')
            .style('font-weight', '600')
            .style('fill', this.colors.text)
            .text('Publications Overview');

        container.append('text')
            .attr('class', 'chart-subtitle')
            .attr('x', 0)
            .attr('y', -10)
            .style('font-size', '12px')
            .style('fill', this.colors.text)
            .style('opacity', 0.8)
            .text('Publications grouped by type and year');
    }

    createLinks(container, root) {
        const links = container.selectAll('.link')
            .data(root.descendants().slice(1))
            .enter().append('path')
            .attr('class', 'link')
            .attr('d', d => {
                return `M${d.y},${d.x}
                        C${(d.parent.y + d.y) / 2},${d.x}
                         ${(d.parent.y + d.y) / 2},${d.parent.x}
                         ${d.parent.y},${d.parent.x}`;
            })
            .style('fill', 'none')
            .style('stroke', this.colors.link)
            .style('stroke-width', '1.5px');
    }

    createNodes(container, root) {
        const nodeGroups = container.selectAll('.node')
            .data(root.descendants())
            .enter().append('g')
            .attr('class', d => `node ${d.children ? 'node--internal' : 'node--leaf'}`)
            .attr('transform', d => `translate(${d.y},${d.x})`);

        const circles = nodeGroups.append('circle')
            .attr('r', d => d.depth === 0 ? 10 : d.children ? 8 : 5)
            .style('fill', d => {
                if (d.depth === 0) return this.colors.text;
                if (d.children) return this.colors.primary;
                return this.colors.secondary;
            })
            .style('stroke', 'white')
            .style('stroke-width', '2px')
            .style('cursor', 'pointer');

        const labels = nodeGroups.append('text')
            .attr('dy', 3)
            .attr('x', d => d.children ? -10 : 10)
            .style('text-anchor', d => d.children ? 'end' : 'start')
            .style('font-size', d => d.depth === 0 ? '14px' : d.children ? '12px' : '10px')
            .style('font-weight', d => d.depth <= 1 ? '600' : '400')
            .style('fill', this.colors.text)
            .text(d => d.data.name)

        this.addNodeInteractivity(nodeGroups, circles);
    }

    addNodeInteractivity(nodeGroups, circles) {
        nodeGroups
            .on('mouseover', (event, d) => {
                select(event.currentTarget).select('circle')
                    .style('stroke-width', '3px')
                    .style('fill', d => {
                        if (d.depth === 0) return this.colors.accent;
                        if (d.children) return this.colors.accent;
                        return this.colors.primary;
                    });
                let titles;
                if (d.children) {
                    titles = d.leaves()
                        .map(leaf => leaf.data.titles ? leaf.data.titles[0] : leaf.data.name)
                        .slice(0, 5);
                    if (d.leaves().length > 5) {
                        titles.push(`... and ${d.leaves().length - 5} more`);
                    }
                } else {
                    titles = d.data.titles || [d.data.name];
                }

                this.tooltip.show(
                    `<strong>${d.data.name}</strong><br>${titles.join('<br>')}`,
                    event
                );
            })
            .on('mousemove', (event) => {
                this.tooltip.updatePosition(event);
            })
            .on('mouseout', (event, d) => {
                select(event.currentTarget).select('circle')
                    .style('stroke-width', '2px')
                    .style('fill', d => {
                        if (d.depth === 0) return this.colors.text;
                        if (d.children) return this.colors.primary;
                        return this.colors.secondary;
                    });
                this.tooltip.hide();
            });
    }

    update(yearRange) {
        this.render(yearRange);
    }
}