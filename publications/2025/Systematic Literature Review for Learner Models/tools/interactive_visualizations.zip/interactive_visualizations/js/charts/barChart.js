import {
    select,
    scaleLinear,
    scaleBand,
    axisBottom,
    axisLeft,
    max,
    rollup,
} from '../utils/d3-modules.js';

import { CONFIG } from '../config.js';
import { DataLoader } from '../utils/dataLoader.js';
import { getDimensions } from '../utils/helpers.js';
import { Tooltip, clearContainer, createSVG } from '../utils/helpers.js';

export class BarChart {
    constructor(container, data) {
        this.container = container;
        this.data = data;
        this.config = getDimensions('bar');
        this.colors = CONFIG.colors;
        this.tooltip = new Tooltip();

        this.svg = null;
        this.xScale = null;
        this.yScale = null;

        this.init();
    }

    init() {
        clearContainer(this.container);
        this.createSVG();
        this.setupScales();
    }

    createSVG() {
        this.svg = createSVG(this.container, this.config.width, this.config.height);
    }

    setupScales() {
        this.xScale = scaleBand()
            .range([this.config.margin.left, this.config.width - this.config.margin.right])
            .padding(0.1);

        this.yScale = scaleLinear()
            .range([this.config.height - this.config.margin.bottom, this.config.margin.top]);
    }

    addTitle(container) {
        container.append('text')
            .attr('class', 'chart-title')
            .attr('x', 0)
            .attr('y', -30)
            .style('font-size', '18px')
            .style('font-weight', '600')
            .style('fill', this.colors.text)
            .text('Publications per Year');

        container.append('text')
            .attr('class', 'chart-subtitle')
            .attr('x', 0)
            .attr('y', -10)
            .style('font-size', '12px')
            .style('fill', this.colors.text)
            .style('opacity', 0.8)
            .text(`Number of publications per year`);
    }

    render(yearRange) {
        const [startYear, endYear] = yearRange;
        const filteredData = DataLoader.filterByYearRange(this.data, startYear, endYear);

        // Group by year and count
        const yearCounts = rollup(filteredData, v => v.length, d => d.year);

        // Transform to arrays for D3 scales
        const years = Array.from(yearCounts.keys()).sort();
        const counts = years.map(year => yearCounts.get(year));

        this.xScale.domain(years);
        this.yScale.domain([0, max(counts)]).nice();

        this.svg.selectAll('.chart-content').remove();

        const chartGroup = this.svg.append('g')
            .attr('class', 'chart-content')
            .attr('transform', `translate(${this.config.margin.left},${this.config.margin.top})`);

        this.addTitle(chartGroup);
        this.createAxes(chartGroup, years, counts);
        this.createBars(chartGroup, years, yearCounts);
    }

    createAxes(container) {
        const xAxis = axisBottom(this.xScale)
            .tickFormat(d => d.toString());

        const yAxis = axisLeft(this.yScale);

        const xAxisGroup = container.append('g')
            .attr('class', 'x-axis')
            .attr('transform', `translate(0,${this.yScale.range()[0]})`)
            .call(xAxis);

        xAxisGroup.append('text')
            .attr('x', this.config.width / 2)
            .attr('y', 40)
            .attr('fill', this.colors.text)
            .attr('text-anchor', 'middle')
            .style('font-size', '14px')
            .style('font-weight', '500')
            .text('Year');

        const yAxisGroup = container.append('g')
            .attr('class', 'y-axis')
            .attr('transform', `translate(${this.config.margin.left},0)`)
            .call(yAxis);

        yAxisGroup.append('text')
            .attr('x', -this.config.height / 2)
            .attr('y', -50)
            .attr('transform', 'rotate(-90)')
            .attr('fill', this.colors.text)
            .attr('text-anchor', 'middle')
            .style('font-size', '14px')
            .style('font-weight', '500')
            .text('Number of Publications');

        container.selectAll('.domain, .tick line')
            .style('stroke', '#e0e0e0');

        container.selectAll('.tick text')
            .style('fill', this.colors.text)
            .style('font-size', '12px');
    }

    createBars(container, years, yearCounts) {
        const bars = container.selectAll('.bar')
            .data(years)
            .enter().append('rect')
            .attr('class', 'bar publication-bar')
            .attr('x', d => this.xScale(d))
            .attr('width', this.xScale.bandwidth())
            .attr('fill', this.colors.primary)
            .style('cursor', 'pointer')
            .attr('y', d => this.yScale(yearCounts.get(d)))
            .attr('height', d => this.config.height - this.config.margin.bottom - this.yScale(yearCounts.get(d)));

        this.addBarInteractivity(bars, yearCounts);
    }

    addBarInteractivity(bars, yearCounts) {
        bars
            .on('mouseover', (event, d) => {
                select(event.target).attr('fill', this.colors.accent);
                this.tooltip.show(
                    `<strong>Year:</strong> ${d}<br><strong>Publications:</strong> ${yearCounts.get(d)}`,
                    event
                );
            })
            .on('mousemove', (event) => {
                this.tooltip.updatePosition(event);
            })
            .on('mouseout', (event) => {
                select(event.target).attr('fill', this.colors.primary);
                this.tooltip.hide();
            });
    }

    update(yearRange) {
        this.render(yearRange);
    }
}