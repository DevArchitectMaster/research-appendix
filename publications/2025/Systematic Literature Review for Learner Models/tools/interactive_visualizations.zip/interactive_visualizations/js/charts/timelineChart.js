import { CONFIG } from '../config.js';
import { DataLoader } from '../utils/dataLoader.js';
import { Tooltip, clearContainer, createSVG } from '../utils/helpers.js';
import {
    scaleLinear,
    scaleBand,
    scaleOrdinal,
    axisBottom,
    axisLeft,
    schemePaired,
    max,
    sum,
    group,
    select
} from '../utils/d3-modules.js';
import { getDimensions } from '../utils/helpers.js';

export class TimelineChart {
    constructor(container, data) {
        this.container = container;
        this.data = data;
        this.config = getDimensions('timeline');
        this.colors = CONFIG.colors;
        this.tooltip = new Tooltip();

        // Define all available attributes
        this.availableAttributes = {
            'dataCategory': 'Data Categories',
            'dataParent': 'Data Parent Categories',
            'dataSource': 'Data Sources',
            'dataSourceSystems': 'Data Source: Systems',
            'collectionMethod': 'Collection Methods',
            'collection': 'Collection Category',
            'dataSourceInit': 'Data Sources (Initialization)',
            'dataSourceSystemsInit': 'Data Source: Systems (Initialization)',
            'collectionMethodInit': 'Collection Methods (Initialization)',
            'collectionInit': 'Collection Category (Initialization)',
            'modelingTechnique': 'Modeling Techniques',
            'domain': 'Domains',
        };

        this.currentAttribute = 'modelingTechnique';
        this.selectedFilters = new Set();

        this.init();
    }

    init() {
        clearContainer(this.container);
        this.createAttributeSelector();
        this.createSVG();
        this.setupScales();
    }

    createAttributeSelector() {
        const containerSelection = select(this.container);

        const selectorContainer = containerSelection.append('div')
            .attr('class', 'attribute-selector')
            .style('margin-bottom', '20px')
            .style('display', 'flex')
            .style('align-items', 'center')
            .style('gap', '15px');

        selectorContainer.append('label')
            .text('Select: ')
            .style('font-weight', 'bold');

        const selector = selectorContainer.append('select')
            .attr('class', 'attribute-dropdown')
            .style('padding', '8px')
            .style('border-radius', '4px')
            .style('border', '1px solid #ccc')
            .on('change', (event) => {
                this.currentAttribute = event.target.value;
                this.update([this.getYearRange()[0], this.getYearRange()[1]]);
            });

        Object.entries(this.availableAttributes).forEach(([key, label]) => {
            selector.append('option')
                .attr('value', key)
                .text(label)
                .property('selected', key === this.currentAttribute);
        });

        this.clearFiltersBtn = selectorContainer.append('button')
            .text('Clear Filters')
            .style('padding', '8px 12px')
            .style('background', '#f0f0f0')
            .style('border', '1px solid #ccc')
            .style('border-radius', '4px')
            .style('cursor', 'pointer')
            .style('display', 'none')
            .on('click', () => {
                this.selectedFilters.clear();
                this.update([this.getYearRange()[0], this.getYearRange()[1]]);
            });
    }

    createSVG() {
        this.svg = createSVG(this.container, this.config.width, this.config.height);
    }

    setupScales() {
        this.xScale = scaleBand()
            .paddingInner(0.1)
            .paddingOuter(0.1);

        this.yScale = scaleLinear();

        const extendedColors = [...schemePaired, ...this.colors.extended];
        this.colorScale = scaleOrdinal()
            .range(extendedColors);
    }

    render(yearRange) {
        const [startYear, endYear] = yearRange;
        let filteredData = DataLoader.filterByYearRange(this.data, startYear, endYear)
            .filter(d => d.detailData);

        this.svg.selectAll('.chart-content').remove();

        const chartGroup = this.svg.append('g')
            .attr('class', 'chart-content')
            .attr('transform', `translate(${this.config.margin.left},${this.config.margin.top})`);

        const groupedData = this.processTimelineData(filteredData);
        this.updateScales(groupedData);

        this.addTitle(chartGroup);

        this.createStackedBars(chartGroup, groupedData);
        this.createAxes(chartGroup);
        this.createLegend(chartGroup);
    }

    addTitle(container) {
        const attributeLabel = this.availableAttributes[this.currentAttribute];

        container.append('text')
            .attr('class', 'chart-title')
            .attr('x', 0)
            .attr('y', -40)
            .style('font-size', '18px')
            .style('font-weight', '600')
            .style('text-anchor', 'start')
            .style('fill', this.colors.text)
            .text(`Evolution of ${attributeLabel} Over Time`);

        container.append('text')
            .attr('class', 'chart-subtitle')
            .attr('x', 0)
            .attr('y', -20)
            .style('font-size', '12px')
            .style('text-anchor', 'start')
            .style('fill', this.colors.text)
            .style('opacity', 0.8)
            .text('Distribution of attributes over time');
    }

    getAttributeValues(dataPoint, attribute) {
        const detailData = dataPoint.detailData;
        if (!detailData) return ['not specified'];

        let value = detailData[attribute];

        if (!value || value === '---' || value === '') {
            return ['not specified'];
        }

        if (typeof value === 'string') {
            // Handle multi-value attributes separated by semicolon
            const values = value.split(';')
                .map(v => v.trim())
                .filter(v => v && v !== '---' && v !== '');

            return values.length > 0 ? values : ['not specified'];
        }

        return [value || 'not specified'];
    }

    processTimelineData(data) {
        const yearGroups = group(data, d => d.year);
        const processedData = [];

        yearGroups.forEach((yearData, year) => {
            const attributeCounts = new Map();

            yearData.forEach(paper => {
                const values = this.getAttributeValues(paper, this.currentAttribute);
                values.forEach(value => {
                    if (!attributeCounts.has(value)) {
                        attributeCounts.set(value, { count: 0, papers: [] });
                    }
                    attributeCounts.get(value).count += 1;
                    attributeCounts.get(value).papers.push(paper);
                });
            });

            attributeCounts.forEach((data, attributeValue) => {
                processedData.push({
                    year: year,
                    attributeValue: attributeValue,
                    count: data.count,
                    papers: data.papers
                });
            });
        });

        return processedData;
    }

    updateScales(data) {
        const years = [...new Set(data.map(d => d.year))].sort();

        const yearTotals = group(data, d => d.year);
        const maxCount = max(Array.from(yearTotals.values()), yearData =>
            sum(yearData, d => d.count)
        );

        this.xScale
            .domain(years)
            .range([0, this.config.width - this.config.margin.left - this.config.margin.right]);

        this.yScale
            .domain([0, maxCount])
            .range([this.config.height - this.config.margin.top - this.config.margin.bottom, 0]);

        this.colorScale
            .domain([...new Set(data.map(d => d.attributeValue))]);
    }

    createStackedBars(container, data) {
        const yearGroups = group(data, d => d.year);

        yearGroups.forEach((yearData, year) => {
            let yOffset = 0;
            const barWidth = this.xScale.bandwidth();

            yearData.forEach(d => {
                const barHeight = this.yScale(0) - this.yScale(d.count);
                const isFiltered = this.selectedFilters.size > 0 && !this.selectedFilters.has(d.attributeValue);

                const originalColor = d.attributeValue === 'not specified' ?
                    this.colors.notSpecified :
                    this.colorScale(d.attributeValue);

                container.append('rect')
                    .attr('class', 'timeline-bar')
                    .attr('x', this.xScale(year))
                    .attr('y', this.yScale(yOffset + d.count))
                    .attr('width', barWidth)
                    .attr('height', barHeight)
                    .attr('fill', originalColor)
                    .attr('stroke', 'white')
                    .attr('stroke-width', 1)
                    .style('opacity', isFiltered ? 0.3 : 1)
                    .style('cursor', 'pointer')
                    .on('click', (event) => {
                        if (this.selectedFilters.has(d.attributeValue)) {
                            this.selectedFilters.delete(d.attributeValue);
                        } else {
                            this.selectedFilters.add(d.attributeValue);
                        }
                        this.update([this.getYearRange()[0], this.getYearRange()[1]]);
                    })
                    .on('mouseover', (event) => {
                        this.tooltip.show(
                            `<strong>${d.attributeValue}</strong><br>
                         Year: ${year}<br>
                         Papers: ${d.count}<br>
                         <em>Click to filter</em><br><br>
                         <strong>Papers:</strong><br>
                         ${d.papers.map(p => `• ${p.title}`).join('<br>')}`,
                            event
                        );
                    })
                    .on('mousemove', (event) => {
                        this.tooltip.updatePosition(event);
                    })
                    .on('mouseout', () => {
                        this.tooltip.hide();
                    });

                yOffset += d.count;
            });
        });
    }

    createAxes(container) {
        container.append('g')
            .attr('class', 'x-axis')
            .attr('transform', `translate(0,${this.config.height - this.config.margin.top - this.config.margin.bottom})`)
            .call(axisBottom(this.xScale));

        container.append('g')
            .attr('class', 'y-axis')
            .call(axisLeft(this.yScale));

        container.append('text')
            .attr('class', 'axis-label')
            .attr('transform', 'rotate(-90)')
            .attr('y', 0 - this.config.margin.left)
            .attr('x', 0 - (this.config.height - this.config.margin.top - this.config.margin.bottom) / 2)
            .attr('dy', '1em')
            .style('text-anchor', 'middle')
            .style('fill', this.colors.text)
            .text('Number of Papers');

        container.append('text')
            .attr('class', 'axis-label')
            .attr('transform', `translate(${(this.config.width - this.config.margin.left - this.config.margin.right) / 2}, ${this.config.height - this.config.margin.top - this.config.margin.bottom + 40})`)
            .style('text-anchor', 'middle')
            .style('fill', this.colors.text)
            .text('Year');
    }

    createLegend(container) {
        const legend = container.append('g')
            .attr('class', 'legend')
            .attr('transform', `translate(20, ${this.config.height - this.config.margin.top - this.config.margin.bottom + 50})`);

        const attributeValues = this.colorScale.domain().slice(0, 8);
        const itemsPerRow = Math.floor((this.config.width - this.config.margin.left - this.config.margin.right) / 180);

        attributeValues.forEach((value, i) => {
            const row = Math.floor(i / itemsPerRow);
            const col = i % itemsPerRow;

            const legendItem = legend.append('g')
                .attr('class', 'legend-item')
                .attr('transform', `translate(${col * 180}, ${row * 20})`)
                .style('cursor', 'pointer')
                .on('click', () => {
                    if (this.selectedFilters.has(value)) {
                        this.selectedFilters.delete(value);
                    } else {
                        this.selectedFilters.add(value);
                    }
                    this.update([this.getYearRange()[0], this.getYearRange()[1]]);
                });

            const isFiltered = this.selectedFilters.size > 0 && !this.selectedFilters.has(value);

            legendItem.append('rect')
                .attr('width', 15)
                .attr('height', 15)
                .attr('fill', value === 'not specified' ? this.colors.notSpecified : this.colorScale(value))
                .style('opacity', isFiltered ? 0.3 : 1);

            legendItem.append('text')
                .attr('class', 'legend-text')
                .attr('x', 20)
                .attr('y', 12)
                .style('font-size', '12px')
                .style('fill', this.colors.text)
                .style('opacity', isFiltered ? 0.5 : 1)
                .text(value.length > 20 ? value.substring(0, 20) + '...' : value);
        });

        legend.append('text')
            .attr('class', 'legend-title')
            .attr('x', 0)
            .attr('y', -10)
            .style('font-size', '14px')
            .style('font-weight', '600')
            .style('fill', this.colors.text)
            .text('Select to filter:');
    }

    getYearRange() {
        const years = this.data.map(d => d.year).filter(y => y);
        return [Math.min(...years), Math.max(...years)];
    }

    update(yearRange) {
        this.render(yearRange);
    }
}