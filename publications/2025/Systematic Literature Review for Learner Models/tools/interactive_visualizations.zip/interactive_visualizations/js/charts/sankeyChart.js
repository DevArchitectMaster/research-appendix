/** Please note: This diagram is currently not in use */

import {
    select,
    zoom,
    sankey,
    sankeyLinkHorizontal
} from '../utils/d3-modules.js';

import { CONFIG } from '../config.js';
import { DataLoader } from '../utils/dataLoader.js';
import { getDimensions } from '../utils/helpers.js';
import { Tooltip, clearContainer, createSVG } from '../utils/helpers.js';

export class SankeyChart {
    constructor(container, data) {
        this.container = container;
        this.data = data;
        this.config = getDimensions('sankey');
        this.colors = CONFIG.colors;
        this.tooltip = new Tooltip();
        this.svg = null;
        this.zoomContainer = null;
        this.sankeyGenerator = null;
        this.currentView = 'init';
        this.zoomBehavior = null;
        this.init();
    }

    init() {
        clearContainer(this.container);
        this.createViewSelector();
        this.createSVG();
        this.setupZoom();
        this.setupSankey();
    }

    createViewSelector() {
        const selectorContainer = select(this.container)
            .insert('div', ':first-child')
            .style('margin-bottom', '10px')
            .style('text-align', 'center');

        const buttonGroup = selectorContainer.append('div')
            .style('display', 'inline-block')
            .style('border', '1px solid #ddd')
            .style('border-radius', '4px')
            .style('overflow', 'hidden');

        ['init', 'update'].forEach(view => {
            buttonGroup.append('button')
                .attr('class', 'sankey-view-btn')
                .attr('data-view', view)
                .style('padding', '8px 16px')
                .style('border', view === 'update' ? '1px solid #ddd' : 'none')
                .style('border-left', view === 'update' ? '1px solid #ddd' : 'none')
                .style('background', this.currentView === view ? this.colors.primary : '#f8f9fa')
                .style('color', this.currentView === view ? 'white' : '#333')
                .style('cursor', 'pointer')
                .style('font-size', '14px')
                .text(view === 'init' ? 'Initial Data Collection' : 'Update Data Collection')
                .on('click', () => this.switchView(view));
        });
    }

    switchView(view) {
        this.currentView = view;
        const self = this;
        select(this.container).selectAll('.sankey-view-btn')
            .style('background', function () {
                return select(this).attr('data-view') === view ? self.colors.primary : '#f8f9fa';
            })
            .style('color', function () {
                return select(this).attr('data-view') === view ? 'white' : '#333';
            });

        if (this.zoomContainer) {
            this.zoomContainer.attr('transform', 'translate(0,0) scale(1)');
        }
        this.render(this.getYearRange());
    }

    getYearRange() {
        return [
            parseInt(document.getElementById('startyear')?.value || 2015),
            parseInt(document.getElementById('endyear')?.value || 2025)
        ];
    }

    createSVG() {
        this.svg = createSVG(this.container, this.config.width, this.config.height);
        this.zoomContainer = this.svg.append('g').attr('class', 'zoom-container');
    }

    setupZoom() {
        this.zoomBehavior = zoom()
            .scaleExtent(CONFIG.settings.zoom.scaleExtent)
            .on('zoom', (event) => this.zoomContainer.attr('transform', event.transform));
        this.svg.call(this.zoomBehavior);
    }

    setupSankey() {
        this.sankeyGenerator = sankey()
            .nodeWidth(25)
            .nodePadding(8)
            .extent([[this.config.margin.left, this.config.margin.top],
            [this.config.width - this.config.margin.right, this.config.height - this.config.margin.bottom]]);
    }

    render(yearRange) {
        const [startYear, endYear] = yearRange;
        const filteredData = DataLoader.filterByYearRange(this.data, startYear, endYear);

        const { nodes, links } = this.currentView === 'init'
            ? this.processDataFlow(filteredData, true)
            : this.processDataFlow(filteredData, false);

        const sankeyData = this.sankeyGenerator({
            nodes: nodes.map(d => ({ ...d })),
            links: links.map(d => ({ ...d }))
        });

        this.zoomContainer.selectAll('.chart-content').remove();
        const chartGroup = this.zoomContainer.append('g').attr('class', 'chart-content');

        this.addTitle(chartGroup);
        this.createLinks(chartGroup, sankeyData.links);
        this.createNodes(chartGroup, sankeyData.nodes);
    }

    addTitle(container) {
        container.append('text')
            .attr('class', 'chart-title')
            .attr('x', 80)
            .attr('y', 40)
            .style('font-size', '18px')
            .style('font-weight', '600')
            .style('text-anchor', 'start')
            .style('fill', this.colors.text)
            .text(`Learner modeling flow when ${this.currentView === 'init' ? 'initializing' : 'updating'} the model`);

        container.append('text')
            .attr('class', 'chart-subtitle')
            .attr('x', 80)
            .attr('y', 60)
            .style('font-size', '12px')
            .style('text-anchor', 'start')
            .style('fill', this.colors.text)
            .style('opacity', 0.8)
            .text('Flow diagram showing learner modeling process');
    }

    processDataFlow(data, isInit) {
        const nodes = [], links = [], nodeMap = new Map();

        const getOrCreateNode = (id, category, name) => {
            if (!nodeMap.has(id)) {
                nodeMap.set(id, nodes.length);
                nodes.push({ id, name: name || id, category });
            }
            return nodeMap.get(id);
        };

        const cleanAndSplit = (value) => {
            if (!value || value === '---' || value === '' || value === null) {
                return ['not specified'];
            }
            const items = value.split(';').map(item => item.trim()).filter(item => item && item !== '---');
            return items.length > 0 ? items : ['not specified'];
        };

        data.forEach(pub => {
            if (!pub.detailData) return;

            const suffix = isInit ? 'Init' : '';
            const dataSources = cleanAndSplit(pub.detailData[`dataSource${suffix}`]);
            const collectionMethods = cleanAndSplit(pub.detailData[`collectionMethod${suffix}`]);
            const collections = cleanAndSplit(pub.detailData[`collection${suffix}`]);
            const dataCategories = cleanAndSplit(pub.detailData.dataCategory);
            const dataParents = cleanAndSplit(pub.detailData.dataParent);
            const modelingTechniques = cleanAndSplit(pub.detailData.modelingTechnique);

            this.createFlowLinks([
                [dataSources, 'source'],
                [collectionMethods, 'method'],
                [collections, 'collection'],
                [dataCategories, 'category'],
                [dataParents, 'parent'],
                [modelingTechniques, 'technique']
            ], nodes, links, getOrCreateNode);
        });

        return { nodes, links };
    }

    createFlowLinks(levels, nodes, links, getOrCreateNode) {
        const nodeGroups = levels.map(([items, category]) =>
            items.map(item => getOrCreateNode(`${category}_${item}`, category, item))
        );

        for (let i = 0; i < nodeGroups.length - 1; i++) {
            nodeGroups[i].forEach(sourceNode => {
                nodeGroups[i + 1].forEach(targetNode => {
                    this.addOrUpdateLink(links, sourceNode, targetNode, 1);
                });
            });
        }
    }

    addOrUpdateLink(links, sourceIndex, targetIndex, weight = 1) {
        const existingLink = links.find(l => l.source === sourceIndex && l.target === targetIndex);
        if (existingLink) {
            existingLink.value += weight;
        } else {
            links.push({ source: sourceIndex, target: targetIndex, value: weight });
        }
    }

    createLinks(container, links) {
        const link = container.append('g').attr('class', 'links')
            .selectAll('.link')
            .data(links)
            .enter().append('path')
            .attr('class', 'link')
            .attr('d', sankeyLinkHorizontal())
            .style('stroke', this.colors.link)
            .style('stroke-width', d => Math.max(1, d.width))
            .style('fill', 'none')
            .style('opacity', 0.6)
            .style('cursor', 'pointer');

        this.addLinkInteractivity(link);
    }

    createNodes(container, nodes) {
        const node = container.append('g').attr('class', 'nodes')
            .selectAll('.node')
            .data(nodes)
            .enter().append('g')
            .attr('class', 'node')
            .attr('transform', d => `translate(${d.x0},${d.y0})`);

        node.append('rect')
            .attr('width', d => d.x1 - d.x0)
            .attr('height', d => d.y1 - d.y0)
            .style('fill', d => {
                if (d.name === 'not specified') {
                    return this.colors.notSpecified;
                }
                return this.getNodeColor(d.category);
            })
            .style('stroke', '#fff')
            .style('stroke-width', 2)
            .style('cursor', 'pointer')
            .style('rx', 3);

        node.append('text')
            .attr('class', 'node-label')
            .attr('x', d => (d.x1 - d.x0) / 2)
            .attr('y', d => (d.y1 - d.y0) / 2)
            .attr('dy', '0.35em')
            .attr('text-anchor', 'middle')
            .style('font-size', '10px')
            .style('font-weight', '500')
            .style('fill', '#fff')
            .style('pointer-events', 'none')
            .text(d => this.truncateText(d.name, d.x1 - d.x0));

        node.append('text')
            .attr('class', 'node-side-label')
            .attr('x', d => {
                const nodeCenter = (d.x0 + d.x1) / 2;
                const chartCenter = this.config.width / 2;
                return nodeCenter < chartCenter ? -10 : (d.x1 - d.x0) + 10;
            })
            .attr('y', d => (d.y1 - d.y0) / 2)
            .attr('dy', '0.35em')
            .attr('text-anchor', d => {
                const nodeCenter = (d.x0 + d.x1) / 2;
                const chartCenter = this.config.width / 2;
                return nodeCenter < chartCenter ? 'end' : 'start';
            })
            .style('font-size', '11px')
            .style('fill', this.colors.text)
            .style('pointer-events', 'none')
            .text(d => d.name);

        this.addNodeInteractivity(node);
    }

    getNodeColor(category) {
        const colorMap = {
            source: this.colors.primary,
            system: '#8B5CF6',
            method: this.colors.secondary,
            collection: '#F59E0B',
            category: this.colors.accent,
            parent: '#10B981',
            technique: '#EF4444'
        };
        return colorMap[category] || this.colors.primary;
    }

    truncateText(text, width) {
        const maxChars = Math.floor(width / 7);
        return text.length > maxChars ? text.substring(0, maxChars - 3) + '...' : text;
    }

    addLinkInteractivity(links) {
        links
            .on('mouseover', (event, d) => {
                select(event.target)
                    .style('opacity', 0.9)
                    .style('stroke-width', Math.max(3, d.width + 1));

                links.style('opacity', 0.5);
                select(event.target).style('opacity', 0.9);

                this.tooltip.show(
                    `<strong>Flow:</strong> ${d.source.name} → ${d.target.name}<br><strong>Publications:</strong> ${d.value}`,
                    event
                );
            })
            .on('mousemove', (event) => this.tooltip.updatePosition(event))
            .on('mouseout', (event, d) => {
                links
                    .style('opacity', 0.5)
                    .style('stroke-width', d => Math.max(1, d.width));

                this.tooltip.hide();
            });
    }

    addNodeInteractivity(nodes) {
        nodes
            .on('mouseover', (event, d) => {
                select(event.currentTarget).select('rect')
                    .style('opacity', 0.8);

                const totalValue = d.sourceLinks.reduce((sum, link) => sum + link.value, 0) ||
                    d.targetLinks.reduce((sum, link) => sum + link.value, 0);

                this.tooltip.show(
                    `<strong>${d.category.charAt(0).toUpperCase() + d.category.slice(1)}:</strong> ${d.name}<br><strong>Publications:</strong> ${totalValue}`,
                    event
                );
            })
            .on('mousemove', (event) => this.tooltip.updatePosition(event))
            .on('mouseout', (event, d) => {
                select(event.currentTarget).select('rect')
                    .style('fill', this.getNodeColor(d.category));
                this.tooltip.hide();
            });
    }

    update(yearRange) {
        this.render(yearRange);
    }
}