import { CONFIG } from '../config.js';
import { DataLoader } from '../utils/dataLoader.js';
import { Tooltip, clearContainer, createSVG, formatTooltipContent } from '../utils/helpers.js';
import { processAuthorPairs } from '../utils/helpers.js';

import {
    select,
    forceSimulation,
    forceLink,
    forceManyBody,
    forceCenter,
    forceCollide,
    drag,
    zoom,
} from '../utils/d3-modules.js';
import { getDimensions } from '../utils/helpers.js';

export class NetworkChart {
    constructor(container, data, options = {}) {
        this.container = container;
        this.data = data;
        this.options = {
            title: 'Publication Network',
            subtitle: 'Connected publications',
            cssPrefix: 'publication',
            linkStrokeWidth: () => 1.5,
            ...options
        };
        this.config = getDimensions('network');
        this.colors = CONFIG.colors;
        this.tooltip = new Tooltip();

        this.svg = null;
        this.simulation = null;
        this.zoomBehavior = null;

        this.init();
    }

    init() {
        clearContainer(this.container);
        this.createSVG();
    }

    createSVG() {
        this.svg = createSVG(this.container, this.config.width, this.config.height);
    }

    render(yearRange) {
        const [startYear, endYear] = yearRange;
        const filteredData = DataLoader.filterByYearRange(this.data, startYear, endYear);

        this.svg.selectAll('.chart-content').remove();

        const chartGroup = this.svg.append('g').attr('class', 'chart-content');
        const zoomGroup = chartGroup.append('g').attr('class', 'zoom-group');

        this.addTitle(chartGroup);
        this.setupZoomBehavior(zoomGroup);

        const { nodes, links } = this.prepareNetworkData(filteredData);

        this.createSimulation(nodes, links);
        this.createLinks(zoomGroup, links);
        this.createNodes(zoomGroup, nodes);
    }

    setupZoomBehavior(zoomGroup) {
        this.zoomBehavior = zoom()
            .scaleExtent(CONFIG.settings.zoom.scaleExtent)
            .on('zoom', (event) => {
                zoomGroup.attr('transform', event.transform);
            });

        this.svg.call(this.zoomBehavior);
    }

    addTitle(container) {
        container.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.config.margin.left)
            .attr('y', this.config.margin.top / 2)
            .style('font-size', '18px')
            .style('font-weight', '600')
            .style('fill', this.colors.text)
            .text(this.options.title);

        container.append('text')
            .attr('class', 'chart-subtitle')
            .attr('x', this.config.margin.left)
            .attr('y', this.config.margin.top / 2 + 20)
            .style('font-size', '12px')
            .style('fill', this.colors.text)
            .style('opacity', 0.8)
            .text(this.options.subtitle);
    }

    prepareNetworkData(data) {
        if (this.options.cssPrefix === 'author') {
            // AUTHOR NETWORK:
            const minCollaborations = CONFIG.settings?.minCollaborations || 2;
            const { filteredPairs, authorTitles } = processAuthorPairs(data, minCollaborations);

            // Create nodes (authors) and links (collaborations)
            const nodes = [];
            const links = [];
            const authorMap = new Map();

            Object.keys(filteredPairs).forEach(pair => {
                const [source, target] = pair.split(" and ");

                if (!authorMap.has(source)) {
                    authorMap.set(source, true);
                    nodes.push({
                        id: source,
                        title: source,
                        titles: authorTitles.get(source) || [],
                        label: source,
                        type: 'author',
                        fx: null,
                        fy: null
                    });
                }
                if (!authorMap.has(target)) {
                    authorMap.set(target, true);
                    nodes.push({
                        id: target,
                        title: target,
                        label: target,
                        titles: authorTitles.get(target) || [],
                        type: 'author',
                        fx: null,
                        fy: null
                    });
                }

                links.push({
                    source: source,
                    target: target,
                    value: filteredPairs[pair].count,
                    titles: filteredPairs[pair].titles
                });
            });

            return { nodes, links };

        } else {
            // VENUE NETWORK:
            const nodes = data.map(d => ({
                id: d.title,
                title: d.title,
                label: d.name,
                venue: d.name,
                year: d.year,
                type: d.type,
                fx: null,
                fy: null
            }));

            const links = [];

            for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                    if (nodes[i].type === nodes[j].type && nodes[i].venue === nodes[j].venue) {
                        links.push({
                            source: nodes[i].id,
                            target: nodes[j].id,
                            venue: nodes[i].venue,
                            type: nodes[i].type,
                            value: 1
                        });
                    }
                }
            }

            return { nodes, links };
        }
    }

    createSimulation(nodes, links) {
        this.simulation = forceSimulation(nodes)
            .force('link', forceLink(links)
                .id(d => d.id)
                .distance(CONFIG.settings.force.linkDistance))
            .force('charge', forceManyBody()
                .strength(CONFIG.settings.force.chargeStrength))
            .force('center', forceCenter(this.config.width / 2, this.config.height / 2))
            .force('collide', forceCollide()
                .radius(CONFIG.settings.force.collideRadius));
    }

    createLinks(container, links) {
        const linkGroup = container.append('g').attr('class', 'links');

        this.linkElements = linkGroup.selectAll('.link')
            .data(links)
            .enter().append('line')
            .attr('class', `link ${this.options.cssPrefix}-link`)
            .style('stroke', this.colors.link)
            .style('stroke-width', this.options.linkStrokeWidth);

        this.linkElements
            .on('mouseover', (event, d) => {
                const currentWidth = this.options.linkStrokeWidth(d);
                select(event.target).style('stroke-width', Math.max(3, currentWidth + 1));

                let tooltipContent;
                if (this.options.cssPrefix === 'author') {
                    tooltipContent = `<strong>Collaborations:</strong> ${d.value}<br><strong>Shared Publications:</strong><br>${d.titles.slice(0, 3).join('<br>')}${d.titles.length > 3 ? '<br>...' : ''}`;
                } else {
                    tooltipContent = `<strong>Venue:</strong> ${d.venue}<br><strong>Type:</strong> ${d.type}`;
                }

                this.tooltip.show(tooltipContent, event);
            })
            .on('mousemove', (event) => {
                this.tooltip.updatePosition(event);
            })
            .on('mouseout', (event, d) => {
                select(event.target).style('stroke-width', this.options.linkStrokeWidth(d));
                this.tooltip.hide();
            });
    }

    createNodes(container, nodes) {
        console.log(nodes);

        const nodeGroup = container.append('g').attr('class', 'nodes');

        this.nodeElements = nodeGroup.selectAll('.node')
            .data(nodes)
            .enter().append('circle')
            .attr('class', `node ${this.options.cssPrefix}-node`)
            .attr('r', 6)
            .style('fill', this.colors.primary)
            .style('stroke', 'white')
            .style('stroke-width', 2)
            .style('cursor', 'pointer')
            .call(this.createDragBehavior());

        this.labelElements = nodeGroup.selectAll('.label')
            .data(nodes)
            .enter().append('text')
            .attr('class', `label ${this.options.cssPrefix}-label`)
            .style('font-size', '8px')
            .style('fill', this.colors.text)
            .style('text-anchor', 'middle')
            .style('pointer-events', 'none')
            .text(d => this.truncateTitle(d.label));

        this.addNodeInteractivity();
        this.simulation.on('tick', () => this.updatePositions());
    }

    truncateTitle(title) {
        return title.length > 20 ? title.substring(0, 20) + '...' : title;
    }

    createDragBehavior() {
        return drag()
            .on('start', (event, d) => {
                if (!event.active) this.simulation.alphaTarget(0.3).restart();
                d.fx = d.x;
                d.fy = d.y;
            })
            .on('drag', (event, d) => {
                d.fx = event.x;
                d.fy = event.y;
            })
            .on('end', (event, d) => {
                if (!event.active) this.simulation.alphaTarget(0);
                d.fx = null;
                d.fy = null;
            });
    }

    addNodeInteractivity() {
        this.nodeElements
            .on('mouseover', (event, d) => {
                select(event.target)
                    .attr('r', 8)
                    .style('stroke-width', 3);

                let tooltipContent;
                if (this.options.cssPrefix === 'author') {
                    tooltipContent = formatTooltipContent({
                        'Author': d.title,
                        'Publications': d.titles.length,
                        'Titles': d.titles.slice(0, 3).join(', ') + (d.titles.length > 3 ? '...' : '')
                    });
                } else {
                    tooltipContent = formatTooltipContent({
                        'Title': d.title,
                        'Venue': d.venue,
                        'Year': d.year,
                        'Type': d.type
                    });
                }

                this.tooltip.show(tooltipContent, event);
            })
            .on('mousemove', (event) => {
                this.tooltip.updatePosition(event);
            })
            .on('mouseout', (event) => {
                select(event.target)
                    .attr('r', 6)
                    .style('stroke-width', 2);

                this.tooltip.hide();
            });
    }

    updatePositions() {
        if (this.linkElements) {
            this.linkElements
                .attr('x1', d => d.source.x)
                .attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x)
                .attr('y2', d => d.target.y);
        }

        if (this.nodeElements) {
            this.nodeElements
                .attr('cx', d => d.x)
                .attr('cy', d => d.y);
        }

        if (this.labelElements) {
            this.labelElements
                .attr('x', d => d.x)
                .attr('y', d => d.y + 15);
        }
    }

    update(yearRange) {
        if (this.simulation) {
            this.simulation.stop();
        }
        this.render(yearRange);
    }
}