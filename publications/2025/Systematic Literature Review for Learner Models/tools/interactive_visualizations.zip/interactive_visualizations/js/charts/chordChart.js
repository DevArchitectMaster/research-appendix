import { CONFIG } from '../config.js';
import { DataLoader } from '../utils/dataLoader.js';
import { Tooltip, clearContainer, createSVG } from '../utils/helpers.js';
import { scaleOrdinal, schemePaired, chord, ribbon, arc, select } from '../utils/d3-modules.js';
import { getDimensions } from '../utils/helpers.js';

export class ChordChart {
    constructor(container, data, options = {}) {
        this.container = container;
        this.data = data;
        this.config = getDimensions('chord');
        this.colors = CONFIG.colors;
        this.tooltip = new Tooltip();
        this.radius = Math.min(this.config.width, this.config.height) / 2 - 120;

        this.options = {
            mode: 'single',
            title: 'Co-Occurrence Analysis (Within)',
            subtitle: 'Relationships and co-occurrences between attributes',
            defaultAttribute1: 'modelingTechnique',
            defaultAttribute2: 'dataSource',
            ...options
        };

        this.availableAttributes = {
            'dataCategory': 'Data Categories',
            'dataParent': 'Data Parent Categories',
            'dataSource': 'Data Sources',
            'dataSourceSystems': 'Data Source: Systems',
            'collectionMethod': 'Collection Methods',
            'collection': 'Collection Category',
            'dataSourceInit': 'Data Sources (Initialization)',
            'dataSourceSystemsInit': 'Data Source: Systems (Initialization)',
            'collectionMethodInit': 'Collection Methods (Initialization)',
            'collectionInit': 'Collection Category (Initialization)',
            'modelingTechnique': 'Modeling Techniques',
            'domain': 'Domains',
        };

        this.currentAttribute = this.options.defaultAttribute1;
        this.attribute1 = this.options.defaultAttribute1;
        this.attribute2 = this.options.defaultAttribute2;

        this.init();
    }

    init() {
        clearContainer(this.container);
        this.createAttributeSelectors();
        this.createSVG();
        this.setupColorScales();
    }

    createAttributeSelectors() {
        const container = select(this.container).append('div')
            .attr('class', 'attribute-selector')
            .style('margin-bottom', '20px')
            .style('display', 'flex')
            .style('flex-wrap', 'wrap')
            .style('align-items', 'center')
            .style('gap', '20px');

        if (this.options.mode === 'single') {
            this.createSelector(container, 'Select Attribute:', this.currentAttribute,
                (value) => { this.currentAttribute = value; this.update(this.getYearRange()); });
        } else {
            this.createSelector(container, 'First Attribute:', this.attribute1,
                (value) => { this.attribute1 = value; this.update(this.getYearRange()); }, this.colors.primary);
            this.createSelector(container, 'Second Attribute:', this.attribute2,
                (value) => { this.attribute2 = value; this.update(this.getYearRange()); }, this.colors.secondary);
        }
    }

    createSelector(container, label, defaultValue, onChange, borderColor = '#ccc') {
        const selectorContainer = container.append('div')
            .style('display', 'flex')
            .style('align-items', 'center')
            .style('gap', '10px');

        selectorContainer.append('label')
            .text(label)
            .style('font-weight', 'bold')
            .style('color', borderColor);

        const selector = selectorContainer.append('select')
            .style('padding', '8px')
            .style('border-radius', '4px')
            .style('border', `2px solid ${borderColor}`)
            .on('change', (event) => onChange(event.target.value));

        Object.entries(this.availableAttributes).forEach(([key, displayLabel]) => {
            selector.append('option')
                .attr('value', key)
                .text(displayLabel)
                .property('selected', key === defaultValue);
        });
    }

    createSVG() {
        this.svg = createSVG(this.container, this.config.width, this.config.height);
    }

    setupColorScales() {
        const colors = [...schemePaired, ...this.colors.extended];
        this.colorScale = scaleOrdinal().range(colors);
        this.colorScale1 = scaleOrdinal().range(colors.filter((_, i) => i % 2 === 0));
        this.colorScale2 = scaleOrdinal().range(colors.filter((_, i) => i % 2 === 1));
    }

    render(yearRange) {
        const filteredData = DataLoader.filterByYearRange(this.data, yearRange[0], yearRange[1])
            .filter(d => d.detailData);

        this.svg.selectAll('.chart-content, .title-group').remove();

        const chartGroup = this.svg.append('g')
            .attr('class', 'chart-content')
            .attr('transform', `translate(${this.config.width / 2}, ${this.config.height / 2})`);

        this.addTitle();

        const { matrix, labels, attributeMapping } = this.processData(filteredData);

        const chords = chord().padAngle(0.05).sortSubgroups((a, b) => b - a)(matrix);

        this.createArcs(chartGroup, chords, labels, attributeMapping);
        this.createRibbons(chartGroup, chords, labels, attributeMapping);
        this.createLegend(labels, attributeMapping);
    }

    processData(data) {

        const cooccurrences = new Map();
        const isCrossMode = this.options.mode === 'cross';

        // Cross-mode: relationships between two different attributes
        if (isCrossMode) {
            return this.processCrossData(data);
        }

        // Single-mode: co-occurrences within one attribute
        const allValues = new Set();

        data.forEach(d => {
            const values = this.extractValues(d.detailData[this.currentAttribute]);
            values.forEach(v => allValues.add(v));

            for (let i = 0; i < values.length; i++) {
                for (let j = i + 1; j < values.length; j++) {
                    const key = [values[i], values[j]].sort().join(' <-> ');
                    cooccurrences.set(key, (cooccurrences.get(key) || 0) + 1);
                }
            }
        });

        const labels = Array.from(allValues).sort();
        const matrix = this.buildMatrix(labels, cooccurrences);

        return { matrix, labels };
    }

    processCrossData(data) {
        const cooccurrences = new Map();
        const attr1Values = new Set();
        const attr2Values = new Set();

        data.forEach(d => {
            const values1 = this.extractValues(d.detailData[this.attribute1]);
            const values2 = this.extractValues(d.detailData[this.attribute2]);

            values1.forEach(v1 => attr1Values.add(v1));
            values2.forEach(v2 => attr2Values.add(v2));

            values1.forEach(v1 => {
                values2.forEach(v2 => {
                    const key = `${v1} <-> ${v2}`;
                    cooccurrences.set(key, (cooccurrences.get(key) || 0) + 1);
                });
            });
        });

        const attr1Labels = Array.from(attr1Values).sort();
        const attr2Labels = Array.from(attr2Values).sort();
        const labels = [...attr1Labels, ...attr2Labels];

        const attributeMapping = {};
        attr1Labels.forEach((label, i) => attributeMapping[i] = { type: 'attr1', label });
        attr2Labels.forEach((label, i) => attributeMapping[attr1Labels.length + i] = { type: 'attr2', label });

        const matrix = this.buildMatrix(labels, cooccurrences);

        return { matrix, labels, attributeMapping };
    }

    extractValues(value) {
        if (!value || value === '---' || value === '') return ['not specified'];
        const values = value.split(';').map(v => v.trim()).filter(v => v && v !== '---');
        return values.length === 0 ? ['not specified'] : values;
    }

    buildMatrix(labels, cooccurrences) {

        // Create symmetric matrix for diagram
        const matrix = Array(labels.length).fill(0).map(() => Array(labels.length).fill(0));

        cooccurrences.forEach((count, key) => {
            const [val1, val2] = key.split(' <-> ');
            const i = labels.indexOf(val1);
            const j = labels.indexOf(val2);
            if (i !== -1 && j !== -1) {
                matrix[i][j] = count;
                matrix[j][i] = count;
            }
        });

        return matrix;
    }

    createArcs(container, chords, labels, attributeMapping) {
        const arcGenerator = arc().innerRadius(this.radius - 20).outerRadius(this.radius);

        container.selectAll('.group')
            .data(chords.groups)
            .enter().append('g')
            .attr('class', 'group')
            .append('path')
            .attr('class', 'arc')
            .attr('d', arcGenerator)
            .attr('fill', d => this.getArcColor(d, labels, attributeMapping))
            .attr('stroke', '#fff')
            .attr('stroke-width', 2)
            .style('cursor', 'pointer')
            .on('mouseover', (event, d) => {
                const tooltipText = this.getArcTooltip(d, labels, attributeMapping);
                this.tooltip.show(tooltipText, event);
            })
            .on('mousemove', (event) => this.tooltip.updatePosition(event))
            .on('mouseout', () => this.tooltip.hide());
    }

    createRibbons(container, chords, labels, attributeMapping) {
        const ribbonGenerator = ribbon().radius(this.radius - 20);

        container.selectAll('.ribbon')
            .data(chords)
            .enter().append('path')
            .attr('class', 'ribbon')
            .attr('d', ribbonGenerator)
            .attr('fill', d => this.getRibbonColor(d, labels, attributeMapping))
            .attr('stroke', '#fff')
            .attr('stroke-width', 1)
            .style('opacity', 0.7)
            .style('cursor', 'pointer')
            .on('mouseover', (event, d) => {
                const tooltipText = this.getRibbonTooltip(d, labels, attributeMapping);
                this.tooltip.show(tooltipText, event);
            })
            .on('mousemove', (event) => this.tooltip.updatePosition(event))
            .on('mouseout', () => this.tooltip.hide());
    }

    getArcColor(d, labels, attributeMapping) {
        const label = attributeMapping ?
            attributeMapping[d.index].label :
            labels[d.index];

        if (label === 'not specified') return this.colors.notSpecified;

        if (attributeMapping) {
            const mapping = attributeMapping[d.index];
            return mapping.type === 'attr1' ? this.colorScale1(label) : this.colorScale2(label);
        }

        return this.colorScale(label);
    }

    getRibbonColor(d, labels, attributeMapping) {
        if (attributeMapping) {
            const sourceMapping = attributeMapping[d.source.index];
            const targetMapping = attributeMapping[d.target.index];

            if (sourceMapping.label === 'not specified' || targetMapping.label === 'not specified') {
                return this.colors.notSpecified;
            }

            if (sourceMapping.type === 'attr1' && targetMapping.type === 'attr2') {
                return this.colorScale1(sourceMapping.label);
            } else if (sourceMapping.type === 'attr2' && targetMapping.type === 'attr1') {
                return this.colorScale2(sourceMapping.label);
            }
            return '#ccc';
        }

        const label = labels[d.source.index];
        return label === 'not specified' ? this.colors.notSpecified : this.colorScale(label);
    }

    getArcTooltip(d, labels, attributeMapping) {
        if (attributeMapping) {
            const mapping = attributeMapping[d.index];
            const attrName = mapping.type === 'attr1' ?
                this.availableAttributes[this.attribute1] :
                this.availableAttributes[this.attribute2];
            return `<strong>${mapping.label}</strong><br>Type: ${attrName}<br>Total connections: ${d.value}`;
        }
        return `<strong>${labels[d.index]}</strong><br>Connections: ${d.value}`;
    }

    getRibbonTooltip(d, labels, attributeMapping) {
        if (attributeMapping) {
            const sourceMapping = attributeMapping[d.source.index];
            const targetMapping = attributeMapping[d.target.index];
            const sourceAttr = sourceMapping.type === 'attr1' ?
                this.availableAttributes[this.attribute1] :
                this.availableAttributes[this.attribute2];
            const targetAttr = targetMapping.type === 'attr1' ?
                this.availableAttributes[this.attribute1] :
                this.availableAttributes[this.attribute2];
            return `<strong>${sourceMapping.label}</strong> (${sourceAttr})<br>↔ <strong>${targetMapping.label}</strong> (${targetAttr})<br>Co-occurrences: ${d.source.value}`;
        }
        return `<strong>${labels[d.source.index]} ↔ ${labels[d.target.index]}</strong><br>Co-occurrences: ${d.source.value}`;
    }

    createLegend(labels, attributeMapping) {
        this.svg.selectAll('.legend').remove();
        const legend = this.svg.append('g')
            .attr('class', 'legend')
            .attr('transform', `translate(${attributeMapping ? 1000 : 1000}, 80)`);

        if (attributeMapping) {
            this.createCrossLegend(legend, attributeMapping);
        } else {
            this.createSingleLegend(legend, labels);
        }
    }

    createSingleLegend(legend, labels) {
        const maxItems = Math.min(labels.length, 15);

        labels.slice(0, maxItems).forEach((label, i) => {
            const item = legend.append('g')
                .attr('transform', `translate(0, ${i * 20})`);

            item.append('rect')
                .attr('width', 15)
                .attr('height', 15)
                .attr('fill', label === 'not specified' ? this.colors.notSpecified : this.colorScale(label));

            item.append('text')
                .attr('x', 20)
                .attr('y', 12)
                .style('font-size', '12px')
                .style('fill', this.colors.text)
                .text(label.length > 25 ? label.substring(0, 25) + '...' : label);
        });

        if (labels.length > maxItems) {
            legend.append('text')
                .attr('y', maxItems * 20 + 15)
                .style('font-size', '11px')
                .style('font-style', 'italic')
                .style('fill', this.colors.text)
                .text(`... and ${labels.length - maxItems} more`);
        }
    }

    createCrossLegend(legend, attributeMapping) {
        const attr1Items = [];
        const attr2Items = [];

        Object.entries(attributeMapping).forEach(([index, mapping]) => {
            const item = { index: parseInt(index), label: mapping.label };
            if (mapping.type === 'attr1') attr1Items.push(item);
            else attr2Items.push(item);
        });

        this.addLegendSection(legend, this.availableAttributes[this.attribute1],
            attr1Items, 0, this.colors.primary, this.colorScale1);

        const attr2Y = 20 + Math.min(attr1Items.length, 8) * 18 + 30;
        this.addLegendSection(legend, this.availableAttributes[this.attribute2],
            attr2Items, attr2Y, this.colors.secondary, this.colorScale2);
    }

    addLegendSection(legend, title, items, startY, titleColor, colorScale) {
        legend.append('text')
            .attr('y', startY)
            .style('font-size', '14px')
            .style('font-weight', 'bold')
            .style('fill', titleColor)
            .text(title);

        items.slice(0, 8).forEach((item, i) => {
            const legendItem = legend.append('g')
                .attr('transform', `translate(0, ${startY + 20 + i * 18})`);

            legendItem.append('rect')
                .attr('width', 12)
                .attr('height', 12)
                .attr('fill', item.label === 'not specified' ? this.colors.notSpecified : colorScale(item.label));

            legendItem.append('text')
                .attr('x', 16)
                .attr('y', 10)
                .style('font-size', '11px')
                .style('fill', this.colors.text)
                .text(item.label.length > 20 ? item.label.substring(0, 20) + '...' : item.label);
        });
    }

    addTitle() {
        const titleGroup = this.svg.append('g').attr('class', 'title-group');

        let titleText = this.options.mode === 'single' ?
            `${this.options.title}: ${this.availableAttributes[this.currentAttribute]}` :
            `${this.options.title}: ${this.availableAttributes[this.attribute1]} ↔ ${this.availableAttributes[this.attribute2]}`;

        titleGroup.append('text')
            .attr('class', 'chart-title')
            .attr('x', this.config.margin.left || 60)
            .attr('y', 40)
            .style('font-size', '18px')
            .style('font-weight', '600')
            .style('text-anchor', 'start')
            .style('fill', this.colors.text)
            .text(titleText);

        titleGroup.append('text')
            .attr('class', 'chart-subtitle')
            .attr('x', this.config.margin.left || 60)
            .attr('y', 60)
            .style('font-size', '12px')
            .style('text-anchor', 'start')
            .style('fill', this.colors.text)
            .style('opacity', 0.8)
            .text(this.options.subtitle);
    }

    getYearRange() {
        const years = this.data.map(d => d.year).filter(y => y);
        return [Math.min(...years), Math.max(...years)];
    }

    update(yearRange) {
        this.render(yearRange);
    }
}