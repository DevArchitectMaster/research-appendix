import { CONFIG } from './config.js';
import { DataLoader } from './utils/dataLoader.js';
import { showError, hideError } from './utils/helpers.js';
import { BarChart } from './charts/barChart.js';
import { TreeChart } from './charts/treeChart.js';
import { NetworkChart } from './charts/networkChart.js';
import { TimelineChart } from './charts/timelineChart.js';
import { ChordChart } from './charts/chordChart.js';
// import { SankeyChart } from './charts/sankeyChart.js';

class PublicationVisualizer {
    constructor() {
        this.data = null;
        this.currentChart = 'publications';
        this.charts = {};

        this.init();
    }

    async init() {
        try {

            this.data = await DataLoader.loadData(CONFIG);

            this.initializeCharts();
            this.setupEventListeners();

            this.showChart('publications');

        } catch (error) {
            showError('Failed to load data.');
        }
    }

    initializeCharts() {
        this.charts = {
            publications: new BarChart('#container1', this.data),
            overview: new TreeChart('#container2', this.data),
            venues: new NetworkChart('#container3', this.data, {
                title: 'Venue Clusters',
                subtitle: 'Connected publications appear in the same journal or conference',
                cssPrefix: 'venue'
            }),
            authors: new NetworkChart('#container4', this.data, {
                title: 'Author Networks',
                subtitle: `Authors with at least ${CONFIG.settings.minCollaborations} joint publications`,
                cssPrefix: 'author',
                // Scale link width by collaboration count
                linkStrokeWidth: (d) => Math.max(1, Math.sqrt(d.value || 1) * 2)
            }),
            timeline: new TimelineChart('#container5', this.data),
            cooccurrences: new ChordChart('#container6', this.data, {
                mode: 'cross',
                title: 'Co-Occurrence Analysis',
                subtitle: 'Relationships within and across attributes. Relationships are counted, so if Item1, Item2, and Item3 occur together, 2 co-occurrences are counted',
                defaultAttribute1: 'dataCategory',
                defaultAttribute2: 'dataCategory' // Default is relationships "within" attributes
            }),
            // sankey: new SankeyChart('#container7', this.data)
        };
    }

    setupEventListeners() {
        document.querySelectorAll('.chart-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const chartType = e.target.dataset.chart;
                this.showChart(chartType);
            });
        });

        document.getElementById('startyear').addEventListener('change', () => this.updateCurrentChart());
        document.getElementById('endyear').addEventListener('change', () => this.updateCurrentChart());
    }

    showChart(chartType) {
        hideError();

        // Hide all chart containers
        document.querySelectorAll('.chart-container').forEach(container => {
            container.style.display = 'none';
        });

        // Show selected chart
        const containerId = this.getContainerId(chartType);
        document.querySelector(containerId).style.display = 'block';

        this.currentChart = chartType;
        this.updateCurrentChart();

        this.updateActiveButton(chartType);
    }

    updateCurrentChart() {
        const yearRange = this.getYearRange();

        if (this.charts[this.currentChart]) {
            this.charts[this.currentChart].update(yearRange);
        }
    }

    updateActiveButton(chartType) {
        document.querySelectorAll('.chart-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        const activeBtn = document.querySelector(`[data-chart="${chartType}"]`);
        if (activeBtn) {
            activeBtn.classList.add('active');
        }
    }

    getContainerId(chartType) {
        const mapping = {
            publications: '#container1',
            overview: '#container2',
            venues: '#container3',
            authors: '#container4',
            timeline: '#container5',
            cooccurrences: '#container6',
            // sankey: '#container7'
        };
        return mapping[chartType];
    }

    getYearRange() {
        const startYear = parseInt(document.getElementById('startyear').value);
        const endYear = parseInt(document.getElementById('endyear').value);
        return [startYear, endYear];
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new PublicationVisualizer();
});