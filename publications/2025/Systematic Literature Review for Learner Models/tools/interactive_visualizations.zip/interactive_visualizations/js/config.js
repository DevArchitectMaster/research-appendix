export const CONFIG = {
    dimensions: {
        default: {
            width: 800,
            height: 600,
            margin: 60
        },

        // Overrides
        overrides: {
            bar: { margin: { top: 80, bottom: 200 } },
            tree: { width: 1200, height: 2400, margin: { top: 80, right: 500 } },
            chord: { width: 1200, height: 800, margin: { top: 80 } },
            timeline: { width: 1000, height: 800, margin: { top: 80, right: 250, bottom: 200 } },
            network: { width: 1200, margin: { top: 80, right: 250 } },
            sankey: { width: 1200, height: 800, margin: { top: 80, right: 150, bottom: 40, left: 150 } }
            // Add further overrides here
        }
    },

    // Color scheme
    colors: {
        primary: '#667eea',
        secondary: '#764ba2',
        accent: '#ff6b35',
        text: '#2d3748',
        link: '#999',
        notSpecified: '#9CA3AF',
        // Extended colors when schemePaired (12) is not enough
        extended: [
            '#8B5A2B',
            '#64748B',
            '#DC2626',
            '#059669',
            '#7C2D12',
            '#1E3A8A',
            '#92400E',
            '#BE185D',
            '#065F46',
            '#7C3AED'
        ]
    },

    // Chart settings
    settings: {
        minCollaborations: 2,
        tooltip: {
            offset: { x: 10, y: -10 },
        },
        zoom: {
            scaleExtent: [0.5, 5]
        },
        force: {
            linkDistance: 50,
            chargeStrength: -30,
            collideRadius: 15
        }
    },

    // Data path
    dataPath: '../../data/data.json'
};