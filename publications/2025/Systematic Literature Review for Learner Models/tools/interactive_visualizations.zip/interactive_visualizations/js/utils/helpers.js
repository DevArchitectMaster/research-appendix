import { select, ascending, hierarchy } from '../utils/d3-modules.js';
import { CONFIG } from '../config.js';

export function showError(message) {
    const errorEl = document.getElementById('error-message');
    if (errorEl) {
        errorEl.textContent = message;
        errorEl.style.display = 'block';
    }
}

export function hideError() {
    const errorEl = document.getElementById('error-message');
    if (errorEl) {
        errorEl.style.display = 'none';
    }
}

export function getDimensions(chartType) {
    const defaults = CONFIG.dimensions.default;
    const overrides = CONFIG.dimensions.overrides[chartType] || {};

    // Merge default config with chart-specific overrides
    const config = {
        width: defaults.width,
        height: defaults.height,
        margin: typeof defaults.margin === 'number'
            ? { top: defaults.margin, right: defaults.margin, bottom: defaults.margin, left: defaults.margin }
            : { ...defaults.margin }
    };

    // Overrides
    if (overrides.width) config.width = overrides.width;
    if (overrides.height) config.height = overrides.height;
    if (overrides.margin) {
        if (typeof overrides.margin === 'number') {
            config.margin = { top: overrides.margin, right: overrides.margin, bottom: overrides.margin, left: overrides.margin };
        } else {
            config.margin = { ...config.margin, ...overrides.margin };
        }
    }

    return config;
}

// Tooltip helpers
export class Tooltip {
    constructor(selector = '#tooltip') {
        this.tooltip = document.querySelector(selector);
        this.isVisible = false;
    }

    show(content, event) {
        if (!this.tooltip) return;

        this.tooltip.innerHTML = content;
        this.tooltip.style.display = 'block';
        this.updatePosition(event);
        this.isVisible = true;
    }

    hide() {
        if (!this.tooltip) return;

        this.tooltip.style.display = 'none';
        this.isVisible = false;
    }

    updatePosition(event) {
        if (!this.tooltip || !event) return;

        const { x, y } = CONFIG.settings.tooltip.offset;
        this.tooltip.style.left = `${event.pageX + x}px`;
        this.tooltip.style.top = `${event.pageY + y}px`;
    }
}

export function formatTooltipContent(data) {
    return Object.entries(data)
        .map(([key, value]) => `<strong>${key}:</strong> ${value}`)
        .join('<br>');
}

export function createSVG(container, width, height) {
    return select(container)
        .append('svg')
        .attr('width', width)
        .attr('height', height);
}

export function clearContainer(container) {
    select(container).selectAll('*').remove();
}

// Data processing helpers
export function processAuthorPairs(data, minCollaborations = 2) {
    const authorPairs = {};
    const authorTitles = new Map();

    data.forEach(d => {
        const authors = d.author.split(' and ').map(a => a.trim());

        authors.forEach(author => {
            if (!authorTitles.has(author)) {
                authorTitles.set(author, []);
            }
            authorTitles.get(author).push(d.title);
        });

        // Create author pairs for collaboration network
        for (let i = 0; i < authors.length; i++) {
            for (let j = i + 1; j < authors.length; j++) {
                const pair = [authors[i], authors[j]].sort().join(' and ');
                if (!authorPairs[pair]) {
                    authorPairs[pair] = { count: 0, titles: [] };
                }
                authorPairs[pair].count++;
                authorPairs[pair].titles.push(d.title);
            }
        }
    });

    // Filter by minimum collaborations
    const filteredPairs = Object.entries(authorPairs)
        .filter(([pair, data]) => data.count >= minCollaborations)
        .reduce((acc, [pair, data]) => {
            acc[pair] = data;
            return acc;
        }, {});

    return { filteredPairs, authorTitles };
}

export function buildHierarchy(data) {
    const root = { name: "root", children: [] };
    const typeMap = new Map();

    data.forEach(d => {
        let typeNode = typeMap.get(d.type);
        if (!typeNode) {
            typeNode = { name: d.type, children: [] };
            typeMap.set(d.type, typeNode);
            root.children.push(typeNode);
        }

        let yearNode = typeNode.children.find(y => y.name === d.year);
        if (!yearNode) {
            yearNode = { name: d.year, children: [] };
            typeNode.children.push(yearNode);
        }

        let nameNode = yearNode.children.find(n => n.name === d.name);
        if (!nameNode) {
            nameNode = { name: d.name, titles: [d.title] };
            yearNode.children.push(nameNode);
        } else {
            nameNode.titles.push(d.title);
        }
    });

    // Sort years in ascending order
    root.children.forEach(typeNode => {
        typeNode.children.sort((a, b) => ascending(a.name, b.name));
    });

    return hierarchy(root);
}