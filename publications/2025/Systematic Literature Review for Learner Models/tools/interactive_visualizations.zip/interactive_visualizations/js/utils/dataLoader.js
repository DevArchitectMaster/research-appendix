export class DataLoader {
    static async loadData(CONFIG) {

        try {
            const response = await fetch(CONFIG.dataPath);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (!Array.isArray(data)) {
                throw new Error('Data must be an array');
            }
            
            const requiredFields = ['title', 'author', 'year', 'type', 'name'];
            const validData = data.filter(item => {
                return requiredFields.every(field => item.hasOwnProperty(field));
            });
            
            if (validData.length === 0) {
                throw new Error('No valid data entries found');
            }
            
            if (validData.length < data.length) {
                console.warn(`${data.length - validData.length} entries were filtered out due to missing required fields`);
            }
            
            validData.forEach(item => {
                item.year = parseInt(item.year);
            });
            
            return validData.sort((a, b) => a.year - b.year);
            
        } catch (error) {
            console.error('Error loading data:', error);
            throw new Error(`Failed to load data: ${error.message}`);
        }
    }

    static getYearRange(data) {
        const years = data.map(d => d.year);
        return [Math.min(...years), Math.max(...years)];
    }

    static filterByYearRange(data, startYear, endYear) {
        return data.filter(d => d.year >= startYear && d.year <= endYear);
    }
}